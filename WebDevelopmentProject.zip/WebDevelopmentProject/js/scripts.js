/**
 * Preloads images to ensure smooth transitions during cycling.
 */
function preloadImages(imageArray) {
    imageArray.forEach(src => {
        const img = new Image();
        img.src = src;
        console.log(`Preloading image: ${src}`);
    });
}

/**
 * Cycles through the images in the banner every 3 seconds.
 */
function cycleBannerImages(images, bannerElement, interval) {
    let currentIndex = 0;

    setInterval(() => {
        currentIndex = (currentIndex + 1) % images.length;
        bannerElement.src = images[currentIndex];
        console.log(`Cycling to image index: ${currentIndex}`);
    }, interval);
}

// On page load, preload images and start cycling banner
document.addEventListener("DOMContentLoaded", function () {
    const bannerImages = [
        "images/banner1.jpg",
        "images/banner2.jpg",
        "images/banner3.jpg"
    ];
    const bannerElement = document.getElementById("banner");
    if (!bannerElement) {
        console.error("Banner element not found. Ensure the element exists in the DOM.");
        return;
    }
    if (bannerImages.length > 0) {
        preloadImages(bannerImages);
        cycleBannerImages(bannerImages, bannerElement, 3000);
    } else {
        console.error("No images found to cycle through.");
    }
});