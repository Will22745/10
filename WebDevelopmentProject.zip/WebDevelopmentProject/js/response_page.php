<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission Response</title>
</head>
<body>
    <h1>Thank You for Contacting Me!</h1>
    <p>Here is the information you submitted:</p>
    <ul>
        <?php
        foreach ($_POST as $key => $value) {
            echo "<li>$key: $value</li>";
        }
        ?>
    </ul>
</body>
</html>
