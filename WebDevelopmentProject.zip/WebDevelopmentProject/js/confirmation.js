/**
 * Reads a specific cookie by name.
 * @param {string} name - The name of the cookie to retrieve.
 * @returns {string|null} - The value of the cookie, or null if not found.
 */
function getCookie(name) {
    const cookieArr = document.cookie.split(';');
    for (const cookie of cookieArr) {
        const [key, value] = cookie.trim().split('=');
        if (key === name) {
            return decodeURIComponent(value);
        }
    }
    return null;
}

/**
 * Parses the query string from the URL and returns an object with key-value pairs.
 * @returns {Object} - The parsed query string as an object.
 */
function parseQueryString() {
    const params = new URLSearchParams(window.location.search);
    const queryData = {};
    for (const [key, value] of params.entries()) {
        queryData[key] = value;
    }
    return queryData;
}

// Parse the query string and cookies to get user data
const queryData = parseQueryString();
const userData = {};

// Combine query string data with cookies for a complete dataset
for (const key in queryData) {
    userData[key] = queryData[key] || getCookie(key);
}

// Display user data on the page
const userDataDiv = document.getElementById('userData');
let html = '<h2>User Data</h2>';

if (Object.keys(userData).length > 0) {
    html += '<ul>';
    for (const [key, value] of Object.entries(userData)) {
        html += `<li>${key}: ${value}</li>`;
    }
    html += '</ul>';
} else {
    html += '<p>No user data available.</p>';
}

userDataDiv.innerHTML = html;
