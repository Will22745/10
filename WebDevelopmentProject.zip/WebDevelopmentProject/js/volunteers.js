var $ = function (id) { return document.getElementById(id); };

var volunteerArray = [];

// Function to display the volunteers in the list
var displayVolunteers = function () {
    var volunteerList = $("volunteerList");
    if (!volunteerList) return;
    volunteerList.innerHTML = ""; // Clear the current list

    // Loop through the array and display each volunteer with their index
    volunteerArray.forEach(function (volunteer, index) {
        var listItem = document.createElement("li");
        listItem.innerHTML = '<span class="index">' + (index + 1) + '.</span> ' + volunteer;
        volunteerList.appendChild(listItem);
    });
};

// Function to add a volunteer to the list
var addVolunteer = function () {
    var volunteerNameElement = $("volunteerName");
    if (!volunteerNameElement) return;
    var volunteerName = volunteerNameElement.value.trim();

    // Check if the input is not empty
    if (volunteerName) {
        // Store the data in the array
        volunteerArray.push(volunteerName);

        // Display the volunteers and clear the input field
        displayVolunteers();
        volunteerNameElement.value = "";
        volunteerNameElement.focus();
        volunteerNameElement.classList.remove("error");
        displayMessage(""); // Clear any previous messages
    } else {
        // Display an error message if the input is empty
        displayMessage("Please enter a volunteer name.");
        volunteerNameElement.classList.add("error");
    }
};

// Function to delete a volunteer from the list
var deleteVolunteer = function () {
    var volunteerNameElement = $("volunteerName");
    if (!volunteerNameElement) return;
    var volunteerName = volunteerNameElement.value.trim();

    // Find the index of the volunteer in the array (case-insensitive)
    var index = volunteerArray.findIndex(volunteer => 
        volunteer.toLowerCase() === volunteerName.toLowerCase());

    // If the volunteer is found, remove it from the array
    if (index !== -1) {
        volunteerArray.splice(index, 1);

        // Display the volunteers and clear the input field
        displayVolunteers();
        volunteerNameElement.value = "";
        volunteerNameElement.focus();
        volunteerNameElement.classList.remove("error");
        displayMessage(""); // Clear any previous messages
    } else {
        // Display an error message if the volunteer is not found
        displayMessage("Volunteer not found.");
        volunteerNameElement.classList.add("error");
    }
};

// Function to display messages to the user
var displayMessage = function (message) {
    var messageElement = $("message");
    if (messageElement) {
        messageElement.textContent = message;
    }
};

// Function to clear the volunteer list
var clearVolunteers = function () {
    // Clear the array
    volunteerArray = [];

    // Remove the volunteers data from the web page
    displayVolunteers();
    var volunteerNameElement = $("volunteerName");
    if (volunteerNameElement) volunteerNameElement.focus();
};

// Function to sort the volunteer list by last name
var sortVolunteers = function () {
    // Sort the array by last name
    volunteerArray.sort(function (a, b) {
        var lastNameA = a.split(" ").slice(-1)[0]?.toLowerCase() || "";
        var lastNameB = b.split(" ").slice(-1)[0]?.toLowerCase() || "";
        return lastNameA.localeCompare(lastNameB);
    });

    // Display the sorted volunteers
    displayVolunteers();
};

// When the page is fully loaded, the buttons will be mapped to the JavaScript functions
window.onload = function () {
    ["add_button", "delete_button", "clear_button", "sort_button"].forEach(id => {
        var button = $(id);
        if (button) {
            var handler = {
                add_button: addVolunteer,
                delete_button: deleteVolunteer,
                clear_button: clearVolunteers,
                sort_button: sortVolunteers,
            }[id];
            button.addEventListener("click", handler);
        }
    });
    if ($("volunteerName")) $("volunteerName").focus();
};