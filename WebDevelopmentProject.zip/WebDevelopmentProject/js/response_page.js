// Wait for the DOM to load before running the script
document.addEventListener("DOMContentLoaded", function () {
    // Select the form using its ID or class
    const form = document.querySelector("form");

    // Check if the form exists before adding the event listener
    if (form) {
        // Add a submit event listener to the form
        form.addEventListener("submit", function (event) {
            // Prevent the form from actually submitting to a server
            event.preventDefault();

            // Gather form data for feedback
            const formData = new FormData(form);
            let message = "Form submitted successfully!\n\nHere is the information you provided:\n";

            // Loop through each form field and append its data to the message
            for (let [name, value] of formData.entries()) {
                message += `${name}: ${value}\n`;
            }

            // Display success message
            alert(message);

            // Reset the form after submission
            form.reset();
        });
    }
});
