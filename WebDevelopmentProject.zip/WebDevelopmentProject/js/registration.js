document.getElementById('registrationForm').addEventListener('submit', handleFormSubmit);

function handleFormSubmit(event) {
    event.preventDefault(); // Prevent default form submission

    // Collect form data
    const formData = new FormData(document.getElementById('registrationForm'));
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
        document.cookie = `${key}=${encodeURIComponent(value)}; path=/`; // Store in cookies
    });

    // Redirect to confirm.html with query string
    const queryString = new URLSearchParams(data).toString();
    window.location.href = `confirm.html?${queryString}`;
}
