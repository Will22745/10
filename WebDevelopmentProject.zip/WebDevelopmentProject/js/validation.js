var $ = function (id) { return document.getElementById(id); };

// Helper function to display error messages
var displayError = function (field, message) {
    var errorElement = $(field + "Error");
    if (!errorElement) {
        errorElement = document.createElement("span");
        errorElement.id = field + "Error";
        errorElement.classList.add("error");
        $(field).parentNode.appendChild(errorElement);
    }
    errorElement.textContent = message;
    $(field).setAttribute("aria-invalid", "true");
};

// Helper function to clear error messages
var clearError = function (field) {
    var errorElement = $(field + "Error");
    if (errorElement) {
        errorElement.textContent = "";
    }
    $(field).removeAttribute("aria-invalid");
};

// Helper function to set cookies
var setCookie = function (name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
};

var validateForm = function () {
    var isValid = true;
    var firstInvalidField = null;

    // Validate required fields
    ["username", "password", "passwordVerify", "email", "phoneNumber"].forEach(function (field) {
        var fieldElement = $(field);
        if (fieldElement && fieldElement.value.trim() === "") {
            displayError(field, "This field is required.");
            isValid = false;
            if (!firstInvalidField) {
                firstInvalidField = fieldElement;
            }
        } else {
            clearError(field);
        }
    });

    // Validate specific field formats
    var username = $("username").value.trim();
    if (username && !/^[a-zA-Z0-9]+$/.test(username)) {
        displayError("username", "Username must contain only letters and numbers.");
        isValid = false;
    }

    var password = $("password").value.trim();
    if (password && !/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
        displayError("password", "Password must be at least 8 characters long and include an uppercase letter, a number, and a special character.");
        isValid = false;
    }

    var passwordVerify = $("passwordVerify").value.trim();
    if (passwordVerify && password !== passwordVerify) {
        displayError("passwordVerify", "Passwords do not match.");
        isValid = false;
    }

    var email = $("email").value.trim();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        displayError("email", "Invalid email format.");
        isValid = false;
    }

    var phoneNumber = $("phoneNumber").value.trim();
    if (phoneNumber && !/^\(\d{3}\) \d{3}-\d{4}$/.test(phoneNumber)) {
        displayError("phoneNumber", "Phone number must be in the format (xxx) xxx-xxxx.");
        isValid = false;
    }

    // Focus on the first invalid field
    if (firstInvalidField) {
        firstInvalidField.focus();
    }

    return isValid;
};

window.onload = function () {
    var form = $("registrationForm"); // Ensure this matches the HTML form ID
    if (form) {
        form.onsubmit = function (event) {
            if (!validateForm()) {
                event.preventDefault();
            } else {
                // Save form data to cookies
                ["username", "email", "phoneNumber"].forEach(function (field) {
                    var fieldElement = $(field);
                    if (fieldElement) {
                        setCookie(field, fieldElement.value.trim(), 7);
                    }
                });
                // Redirect to confirm.html
                window.location.href = "confirm.html";
            }
        };

        // Add real-time validation
        ["username", "password", "passwordVerify", "email", "phoneNumber"].forEach(function (field) {
            var fieldElement = $(field);
            if (fieldElement) {
                fieldElement.oninput = function () {
                    var validateField = {};
                    validateField[field] = function () {
                        var fieldValue = fieldElement.value.trim();
                        if (field === "username" && !/^[a-zA-Z0-9]+$/.test(fieldValue)) {
                            displayError(field, "Username must contain only letters and numbers.");
                        } else if (field === "password" && !/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(fieldValue)) {
                            displayError(field, "Password must be at least 8 characters long and include an uppercase letter, a number, and a special character.");
                        } else if (field === "passwordVerify" && fieldValue !== $("password").value.trim()) {
                            displayError(field, "Passwords do not match.");
                        } else if (field === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fieldValue)) {
                            displayError(field, "Invalid email format.");
                        } else if (field === "phoneNumber" && !/^\(\d{3}\) \d{3}-\d{4}$/.test(fieldValue)) {
                            displayError(field, "Phone number must be in the format (xxx) xxx-xxxx.");
                        } else {
                            clearError(field);
                        }
                    };
                    validateField[field]();
                };
            }
        });
    }
};
