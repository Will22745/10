// JavaScript to dynamically update the invitation placeholders

// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function () {
    // Select the form and placeholders
    const form = document.getElementById("invitationForm"); // Form element
    const recipientPlaceholder = document.getElementById("recipientNamePlaceholder"); // Placeholder for recipient name
    const hostPlaceholder = document.getElementById("hostNamePlaceholder"); // Placeholder for host name

    // Check if form and placeholders exist
    if (!form || !recipientPlaceholder || !hostPlaceholder) {
        console.error("Form or placeholders not found");
        return;
    }

    // Add event listener to the form submit button
    form.addEventListener("submit", function (event) {
        // Prevent default form submission
        event.preventDefault();

        // Get input values
        const recipientNameInput = document.getElementById("recipientNameInput"); // Input field for recipient name
        const hostNameInput = document.getElementById("hostNameInput"); // Input field for host name

        // Check if input elements exist
        if (!recipientNameInput || !hostNameInput) {
            console.error("Input elements not found");
            return;
        }

        // Trim input values to remove extra spaces
        const recipientName = recipientNameInput ? recipientNameInput.value.trim() : "";
        const hostName = hostNameInput ? hostNameInput.value.trim() : "";

        // Input validation: Check if both fields are filled
        if (!recipientName || !hostName) {
            alert("Both fields are required.");
            return;
        }

        // Update placeholders with input values
        recipientPlaceholder.innerText = recipientName;
        hostPlaceholder.innerText = hostName;
    });
});
