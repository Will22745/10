document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    const errorMessages = {};

    function validateField(field, regex, message) {
        const value = field.value.trim();
        if (!regex.test(value)) {
            errorMessages[field.name] = message;
            showError(field, message);
            return false;
        } else {
            clearError(field);
            delete errorMessages[field.name];
            return true;
        }
    }

    function showError(field, message) {
        let errorElement = field.nextElementSibling;
        if (!errorElement || !errorElement.classList.contains("error")) {
            errorElement = document.createElement("span");
            errorElement.classList.add("error");
            field.parentElement.appendChild(errorElement);
        }
        errorElement.textContent = message;
    }

    function clearError(field) {
        const errorElement = field.nextElementSibling;
        if (errorElement && errorElement.classList.contains("error")) {
            errorElement.remove();
        }
    }

    function validateForm() {
        let isValid = true;

        isValid &= validateField(
            document.querySelector("input[name='userName']"),
            /^[a-zA-Z0-9]+$/,
            "Username must contain only letters and numbers."
        );

        isValid &= validateField(
            document.querySelector("input[name='password']"),
            /^.{8,}$/,
            "Password must be at least 8 characters."
        );

        isValid &= validateField(
            document.querySelector("input[name='passwordVerify']"),
            new RegExp(`^${document.querySelector("input[name='password']").value}$`),
            "Passwords must match."
        );

        isValid &= validateField(
            document.querySelector("input[name='email']"),
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
            "Email must be in a valid format (xxx@xxx.xxx)."
        );

        isValid &= validateField(
            document.querySelector("input[name='phoneNumber']"),
            /^\(\d{3}\) \d{3}-\d{4}$/,
            "Phone number must be in the format (xxx) xxx-xxxx."
        );

        return isValid;
    }

    form.addEventListener("submit", (e) => {
        if (!validateForm()) {
            e.preventDefault();
            const firstErrorField = form.querySelector(".error").previousElementSibling;
            firstErrorField.focus();
        }
    });
});
